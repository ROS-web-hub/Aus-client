const starting = require("./starting");

module.exports = { starting };
