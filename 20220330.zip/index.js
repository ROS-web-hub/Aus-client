/**
 * This is the starting point for the app.
 *
 */
"use strict";
const startMenu = require("./src");
const { createLog } = require("./src/utils/log");
//  Show the start Menu with 5 items
createLog();
startMenu();
